# sosS
Python package calculating for a list of numbers the sum of squares and squares it. 
